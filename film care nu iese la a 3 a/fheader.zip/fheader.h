
typedef struct Site Site_t;

Site_t* initializare();
Site_t* adaugare(Site_t*, char*, char*, int, int); 
void afisareFilme(Site_t*);
void afisareMaxim(Site_t*);